var _batdox_filter_8bat =
[
    [ "BAT_code", "_batdox_filter_8bat.html#a400ec3e306ebbb4d3373e224ee4db4c7", null ]
];