var _batdox_filter_8sh =
[
    [ "bat_filter", "_batdox_filter_8sh.html#a0fd9216ac241b6cfa91d69b07db428c5", null ],
    [ "call_using", "_batdox_filter_8sh.html#a468d0fdcf8118ef716a724fca330f794", null ]
];