var _x_m_ldox_filter_8sh =
[
    [ "xml_filter", "_x_m_ldox_filter_8sh.html#aa0d21ebcb95e54a6db922330058a0c14", null ],
    [ "call_using", "_x_m_ldox_filter_8sh.html#a2a5b8503030f5315d6bde8cbe5377ad5", null ]
];