var annotated_dup =
[
    [ "ms", "namespacems.html", "namespacems" ],
    [ "regexfilter", "classregexfilter.html", "classregexfilter" ],
    [ "xmlfilter", "classxmlfilter.html", "classxmlfilter" ],
    [ "xslt2doxfilter", "classxslt2doxfilter.html", "classxslt2doxfilter" ],
    [ "ZeroFilter", "class_zero_filter.html", "class_zero_filter" ]
];