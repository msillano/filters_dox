var class_zero_filter =
[
    [ "startup", "class_zero_filter.html#aa625396a4b99d02656052d61022229cc", null ],
    [ "newline", "class_zero_filter.html#aa70d1a80bbc88066d8ec0869842fd46c", null ],
    [ "aaBase", "class_zero_filter.html#afa4c6eece2117f7ebd1f78272e17b354", null ],
    [ "inFile", "class_zero_filter.html#a1bd069ea583efa4344d7603d18796dd5", null ],
    [ "fin", "class_zero_filter.html#a01b9e35e65a11d7df0bd78503f5c7bcf", null ],
    [ "outFile", "class_zero_filter.html#a1b9d2a5e09c608ea345338bfe6e072c1", null ],
    [ "fout", "class_zero_filter.html#a69e1a8280fedd9946e9a66590b527b3c", null ]
];