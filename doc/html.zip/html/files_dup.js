var files_dup =
[
    [ "bin", "dir_2ea30aa2956a8db99dd22aa5e597f384.html", "dir_2ea30aa2956a8db99dd22aa5e597f384" ],
    [ "sample_files", "dir_704fe1c3032d351198a578f661d61d49.html", "dir_704fe1c3032d351198a578f661d61d49" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "BatdoxFilter.bat", "_batdox_filter_8bat.html", "_batdox_filter_8bat" ],
    [ "BatdoxFilter.sh", "_batdox_filter_8sh.html", "_batdox_filter_8sh" ],
    [ "HTMLdoxFilter.bat", "_h_t_m_ldox_filter_8bat.html", "_h_t_m_ldox_filter_8bat" ],
    [ "HTMLdoxFilter.sh", "_h_t_m_ldox_filter_8sh.html", "_h_t_m_ldox_filter_8sh" ],
    [ "RGXdoxFilter.bat", "_r_g_xdox_filter_8bat.html", "_r_g_xdox_filter_8bat" ],
    [ "RGXdoxFilter.sh", "_r_g_xdox_filter_8sh.html", "_r_g_xdox_filter_8sh" ],
    [ "ShdoxFilter.bat", "_shdox_filter_8bat.html", "_shdox_filter_8bat" ],
    [ "ShdoxFilter.sh", "_shdox_filter_8sh.html", "_shdox_filter_8sh" ],
    [ "XMLdoxFilter.bat", "_x_m_ldox_filter_8bat.html", "_x_m_ldox_filter_8bat" ],
    [ "XMLdoxFilter.sh", "_x_m_ldox_filter_8sh.html", "_x_m_ldox_filter_8sh" ],
    [ "XSLTdoxFilter.bat", "_x_s_l_tdox_filter_8bat.html", "_x_s_l_tdox_filter_8bat" ],
    [ "XSLTdoxFilter.sh", "_x_s_l_tdox_filter_8sh.html", "_x_s_l_tdox_filter_8sh" ]
];