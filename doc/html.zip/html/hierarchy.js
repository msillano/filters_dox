var hierarchy =
[
    [ "ZeroFilter", "class_zero_filter.html", [
      [ "regexfilter", "classregexfilter.html", null ],
      [ "xmlfilter", "classxmlfilter.html", null ],
      [ "xslt2doxfilter", "classxslt2doxfilter.html", null ]
    ] ],
    [ "Properties", null, [
      [ "ms.utils.aarray.AArray", "classms_1_1utils_1_1aarray_1_1_a_array.html", [
        [ "ms.utils.aarray.baseapp.AABaseAppl", "classms_1_1utils_1_1aarray_1_1baseapp_1_1_a_a_base_appl.html", null ]
      ] ]
    ] ]
];