var namespaces_dup =
[
    [ "ms", "namespacems.html", "namespacems" ]
];