var node_print_col_8xsl =
[
    [ "xslt_nodeprintcol_template_01", "node_print_col_8xsl.html#a1b13f35dd757c928436be09673c31e50", null ],
    [ "INLINE_HEADER", "node_print_col_8xsl.html#a2bb698ba43a4fc380029011cf4177e86", null ],
    [ "status", "node_print_col_8xsl.html#a40bd12449194f0f8cff0b516cb4add0b", null ]
];